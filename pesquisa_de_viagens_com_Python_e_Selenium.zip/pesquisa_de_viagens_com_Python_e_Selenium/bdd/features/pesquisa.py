from behave import given, when, then

@given(u'que acesso ao website para efetuar uma pesquisa')
def step_impl(context):
    pass

@when(u'preencho os campos com dados válidos')
def step_impl(context):
    pass

@then(u'o serviço retorna o resultado da pesquisa')
def step_impl(context):
    pass

