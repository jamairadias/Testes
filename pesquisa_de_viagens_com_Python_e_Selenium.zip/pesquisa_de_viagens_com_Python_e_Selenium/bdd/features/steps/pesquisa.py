from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By 
from selenium.common.exceptions import NoSuchElementException 
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep



@given(u'que acesso ao website para efetuar uma pesquisa')
def step_impl(context):
    chrome_path = 'C:\webdrivers\chromedriver\83\chromedriver.exe'
    context.web = webdriver.Chrome(chrome_path)
    context.web.get('https://www.voeazul.com.br/')
    context.web.maximize_window()




@when(u'preencho os campos com dados válidos')
def step_impl(context):
    context.element = context.web.find_element_by_id("field-1-origin1")
    context.element.click()
    context.element.send_keys("Congonhas")
    context.element = context.web.find_element_by_xpath('//*[@id="tab-round-trip"]/div[1]/div[1]/div[2]/div[1]/div/ul/li').click()
    sleep(3)
    context.element = context.web.find_element_by_id("field-2-destination1")
    context.element.click()
    context.element.send_keys("Maceio")
    context.element = context.web.find_element_by_xpath('//*[@id="tab-round-trip"]/div[1]/div[3]/div[2]/div[1]/div/ul/li').click()
    sleep(3)
    context.element = context.web.find_element_by_id("incrementAdults")
    context.element.click()
    sleep(2)
    context.element = context.web.find_element_by_name("departure1")
    context.element.click()
    context.element.send_keys("01/12/2020")
    context.element = context.web.find_element_by_name("arrival")
    context.element.click()
    context.element.send_keys("20/12/2020")
    sleep(3)

    context.element = context.web.find_element_by_id('searchTicketsButton').click()
    
    

@then(u'o serviço retorna o resultado da pesquisa')
def step_impl(context):
    sleep(15)
    context.web.close()